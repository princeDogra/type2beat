# type2beat
1  in every 6 Australian senior citizens age above 65 years suffers from diabetes and 90% percent of them have diabetes type 2. There are several factors that contribute to thrive diabetes type 2 but bad eating habits especially high sugar intake and less physical activities  are the major contributing factors.

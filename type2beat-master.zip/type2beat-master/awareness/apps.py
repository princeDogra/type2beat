from django.apps import AppConfig


class AwarenessConfig(AppConfig):
    name = 'awareness'
